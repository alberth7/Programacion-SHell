# ! /bin/bash

# Proggrama para Ejemplificar el paso de opcions con o sin parametros 
# author: Alberth Apaza

echo "Programa opciones"
echo "Opcion 1 enviada:  $1"
echo "Opcion 2  enviadas: $2"
echo "Opcion enviadas $*"
echo -e "\n"
echo "Recupoerar los valores"
while [ -n "$1" ]
do
case "$1" in
-a) echo "-a opcion utilizada: ";;
-b) echo "-b opcion utilizada: ";;
-c) echo "-c opcion utilizada: ";;
*) echo "$!  / no es una opcion: ";;
esac
shift
done 




